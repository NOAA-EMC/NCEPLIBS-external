/* a list of aliases
 *
 * public domain 2/2007 Wesley Ebisuzaki
 */

#include <stdio.h>
/*
 * HEADER:200:disc=f_code_table_0_0:inv:0:discipline (code table 0.0)
 * HEADER:-1:v1=f_v:misc:0:verbose (v=1)
 * HEADER:-1:quit=f_end:misc:0:stop after first (sub)message (save time)
 * HEADER:200:process=f_code_table_4_3:inv:0:Process (code table 4.3)
 * HEADER:200:-version=f_version:misc:0:print version
 */

// removed   2/2015 * HEADER:200:pdt=f_code_table_4_0:inv:0:product definition template (PDT)
