#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "grb2.h"
#include "wgrib2.h"
#include "fnlist.h"

/* 2/2008 in public domain Wesley Ebisuzaki */

/*
 * HEADER:100:fi:output:0:null output operation
 */

int f_fi(ARG0) {
    return 0;
}

